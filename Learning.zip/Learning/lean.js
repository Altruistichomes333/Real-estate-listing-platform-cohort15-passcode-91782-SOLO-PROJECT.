
let d;
d = new Date();

// d = d. toString();
// d = d.getTime();
// d = d.getMonth()+1;
// d = d.getDay();
// d = `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`;
    // console.log(d);     

    const s = new String('Hello world');
    x = s.typeOf;
    // x = s.length;
    x = s.toUpperCase();
    x = s.indexOf('d');
    x = s.__Proto__;
    X = s.substring(6);
    x = s.replace('world','Israel');
    x = s.includes('hero');
    x = s.valueOf();
    x = s.split('');
    x = s.slice(-11,-6)
    ;

    console.log(x);